import React from 'react';
import NotFound from './index.jsx';
import renderer from 'react-test-renderer';

test('notFound Component', () => {
    const tree = renderer.create(
        <NotFound />
    ).toJSON();
    expect(tree).toMatchSnapshot();
});