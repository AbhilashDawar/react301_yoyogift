export default {
    appName: 'Yo Yo Gift',
    rangeDefaults: {
        min: 0,
        max: 100000
    }
}