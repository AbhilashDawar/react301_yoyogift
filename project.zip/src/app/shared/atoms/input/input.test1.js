// import React from 'react';
// import AppInput from './index.jsx';
// import renderer from 'react-test-renderer';

// test('AppInput Component', () => {
//     const tree = renderer.create(
//         <AppInput />
//     ).toJSON();
//     expect(tree).toMatchSnapshot();
// });